
# Srivarshini P — Portfolio (Streamlit)

This is a simple one-page portfolio built with Streamlit and ready to deploy on Streamlit Community Cloud.

## Files
- `app.py` — the Streamlit app
- `requirements.txt` — Python dependencies

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy (short version)
1. Push this folder to a **public GitHub repo**.
2. Go to https://share.streamlit.io (Streamlit Community Cloud).
3. Sign in with GitHub → New app → pick your repo, branch `main`, and `app.py` as the main file.
4. Click **Deploy**. Share your live link!
