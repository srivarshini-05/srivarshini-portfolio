
import streamlit as st

# -------------------
# Basic Config
# -------------------
st.set_page_config(page_title="Srivarshini P - Portfolio", page_icon="💻", layout="wide")

# -------------------
# Header Section
# -------------------
st.title("👩‍💻 Srivarshini P")
st.subheader("Student at St. Joseph's College of Engineering | Full-Stack Developer | AI/ML Enthusiast")

left, right = st.columns([3,2])
with left:
    st.write("📍 Chennai | ✉️ psrivarshini80@gmail.com | 📱 7538848395")
    st.write("[🔗 LinkedIn](https://www.linkedin.com/in/srivarshini-p-589a74291)")
with right:
    st.markdown(
        '<div style="text-align:right;">'
        '<a href="mailto:psrivarshini80@gmail.com">📨 Contact Me</a>'
        '</div>',
        unsafe_allow_html=True
    )

st.markdown("---")

# -------------------
# Profile
# -------------------
st.header("About Me")
st.write("""
Motivated Computer Science student passionate about full-stack development and problem-solving.  
Proficient in **Python, Java, MySQL**, with a growing interest in **AI/ML technologies**.  
Solved **140+ LeetCode problems** with a 100-day streak, demonstrating strong logic and consistency.  
Experienced in user-focused design, software development, and effective team collaboration.  
Seeking opportunities to apply technical and analytical skills to real-world challenges.
""")

# -------------------
# Skills
# -------------------
st.header("Skills")
cols = st.columns(3)
with cols[0]:
    st.subheader("Programming")
    st.write("Python, Java")
with cols[1]:
    st.subheader("Databases")
    st.write("MySQL")
with cols[2]:
    st.subheader("Frontend & Design")
    st.write("HTML, CSS, JavaScript, Figma, Canva")

# -------------------
# Education
# -------------------
st.header("Education")
st.write("""
- 🎓 **B.E. Computer Science** – St. Joseph's College Of Engineering (2023–2027), CGPA: 9.17  
- 📘 Higher Secondary – Babaji Vidhyashram (2022–2023), 92.2%  
- 📘 High School – Velammal Vidhyashram (2020–2021), 90.4%  
""")

# -------------------
# Projects
# -------------------
st.header("Projects")
with st.expander("📦 Stock Management System (Python, MySQL)", expanded=True):
    st.write("Designed and developed for a stationery shop to teach inventory concepts to accountancy students.")

with st.expander("🌱 AI-Driven Cauliflower Disease Detection (Python, ML, Google Colab)", expanded=True):
    st.write("ML prototype to identify cauliflower plant diseases and suggest relevant treatments.")

with st.expander("📚 Smart Notes & Study Material Hub – Phase 1 (Streamlit, FastAPI, SQLite)", expanded=True):
    st.write("Full-stack academic collaboration platform with notes, likes, comments, follow/unfollow, and private messaging.")

# -------------------
# Internship Experience
# -------------------
st.header("Internship Experience")
st.write("""
- 💻 **Mphasis Ltd. — Full Stack Developer Intern (05/2025 – Present, Porur, Chennai)**  
  Built an Innovation Portal prototype and a document segregation system that classifies PDFs.

- 🎨 **RETECH Solutions Pvt Ltd — UI/UX Designer (07/2024, Tambaram)**  
  15-day internship; received positive feedback for creativity and attention to detail.

- 📈 **Younity.in — Business Development Specialist Intern (11/2023, Chennai)**  
  Completed a 14-day program; generated ₹4,250 revenue and earned a Certificate of Excellence.
""")

# -------------------
# Certifications
# -------------------
st.header("Certifications")
st.write("""
- Python Programming — Younity (Nov 2023)  
- Introduction to Machine Learning — NPTEL (Jul–Sep 2024)  
- Python for Data Science — NPTEL (Jan–Feb 2025)  
- Introduction to Data Science — Cisco  
- Introduction to MongoDB — MongoDB University  
""")

# -------------------
# Key Achievements
# -------------------
st.header("Key Achievements")
st.write("""
- 🏆 1st Place — Technical Quiz @ SIMATS Wissennaire’3  
- 🥇 1st Place — Technical Quiz @ Crescent Arcane’24 (Board Bully)  
- 🥈 Top 10 — CFTRI Food Hackathon  
- 🥉 4th Place — INNOVATHON’25 — Ideathon  
- 🥈 Elite Silver Certification — Python for Data Science  
""")

# -------------------
# Contact
# -------------------
st.header("Contact")
st.write("**Email:** psrivarshini80@gmail.com")
st.write("**Phone:** 7538848395")
st.write("**LinkedIn:** https://www.linkedin.com/in/srivarshini-p-589a74291")
st.write("""
If you'd like to collaborate or discuss opportunities, feel free to reach out.  
I'm open to internships, freelance projects, and mentorship conversations.
""")
